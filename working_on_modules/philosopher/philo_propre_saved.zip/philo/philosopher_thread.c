/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosopher_thread.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: achappui <achappui@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/05 01:13:03 by achappui          #+#    #+#             */
/*   Updated: 2024/02/10 18:17:40 by achappui         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

static char	thinkk(t_philo *philo)
{
	unsigned int	time;

	pthread_mutex_lock(&philo->datas->global_lock);
	if (philo->datas->end_status)
		return (0);
	time = get_time(&philo->datas->start_time);
	printf("\e[0m%u \e[1;37m%d \e[1;34mis thinking\n", time, philo->id);
	pthread_mutex_unlock(&philo->datas->global_lock);
	return (1);
}

static char	eatt(t_philo *philo)
{
	unsigned int	time;

	pthread_mutex_lock(&philo->eating_start);
	// pthread_mutex_lock(philo->right_fork);
	// pthread_mutex_lock(philo->left_fork);
	pthread_mutex_lock(&philo->datas->global_lock);
	if (philo->datas->end_status)
	{
		pthread_mutex_unlock(&philo->eating_start);
		pthread_mutex_unlock(&philo->eating_end);
		return (0);
	}
	time = get_time(&philo->datas->start_time);
	printf(	"\e[0m%u \e[1;37m%d \e[1;33mhas taken a fork\n"
			"\e[0m%u \e[1;37m%d \e[1;33mhas taken a fork\n"
			"\e[0m%u \e[1;37m%d \e[1;31mis eating\n", 
			time, philo->id, time, philo->id, time, philo->id);
	philo->last_meal = time;
	if (++philo->meal_counter == philo->datas->meal_limit)
		if (++philo->datas->finished_eating == philo->datas->nb_of_philo)
			philo->datas->end_status = 1;
	pthread_mutex_unlock(&philo->datas->global_lock);
	usleep(philo->datas->time_to_eat);
	// pthread_mutex_unlock(philo->right_fork);
	// pthread_mutex_unlock(philo->left_fork);
	pthread_mutex_unlock(&philo->eating_end);
	return (1);
}

static char	sleepp(t_philo *philo)
{
	unsigned int	time;

	pthread_mutex_lock(&philo->datas->global_lock);
	if (philo->datas->end_status)
		return (0);
	time = get_time(&philo->datas->start_time);
	printf("\e[0m%u \e[1;37m%d \e[0;36mis sleeping\n", time, philo->id);
	pthread_mutex_unlock(&philo->datas->global_lock);
	usleep(philo->datas->time_to_sleep);
	return (1);
}

void	*philosopher_thread(void *args)
{
	t_philo		*philo;
	pthread_t	death_timer;

	philo = (t_philo *)args;
	pthread_create(&death_timer, NULL, &counter_thread, philo);
	while (1)
	{
		if (!thinkk(philo))
			break ;
		if (!eatt(philo))
			break ;
		if (!sleepp(philo))
			break ;
	}
	philo->datas->threads_finished++;
	pthread_mutex_unlock(&philo->datas->global_lock);
	pthread_join(death_timer, NULL);
	return (NULL);
}
