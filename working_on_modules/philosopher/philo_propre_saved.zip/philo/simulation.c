/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   simulation.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: achappui <achappui@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/09 16:18:16 by achappui          #+#    #+#             */
/*   Updated: 2024/02/10 18:19:57 by achappui         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

static void	give_eating_start(t_philo *philos, unsigned int start, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n)
	{
		pthread_mutex_unlock(&philos[start].eating_start);
		start = (start + 2) % n;
		i++;
	}
}

static void	wait_eating_end(t_philo *philos, unsigned int start, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n)
	{
		pthread_mutex_lock(&philos[start].eating_end);
		start = (start + 2) % n;
		i++;
	}
}

static char	philo_threads_finished(t_datas *datas)
{
	pthread_mutex_lock(&datas->global_lock);
	if (datas->threads_finished == datas->nb_of_philo)
	{
		pthread_mutex_unlock(&datas->global_lock);
		return (1);
	}
	pthread_mutex_unlock(&datas->global_lock);
	return (0);
}

void	simulation_monitor(t_datas *datas, t_philo *philos)
{
	unsigned int	start;
	unsigned int	n;

	start = 0;
	n = datas->nb_of_philo / 2;
	while (1)
	{
		give_eating_start(philos, start, n);
		wait_eating_end(philos, start, n);
		if (philo_threads_finished(datas))
			break ;
		start = (start + 2) % datas->nb_of_philo;
	}
}