/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   initializers.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: achappui <achappui@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/07 18:01:38 by achappui          #+#    #+#             */
/*   Updated: 2024/02/10 18:24:47 by achappui         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

char	init_datas(t_datas *datas, int argc, char *argv[])
{
	int	i;

	if (argc != 5 && argc != 6)
		return (0 * write(1, "ERROR: invalid arguments\n", 25));
	i = 0;
	while (++i < argc)
		if (!valid_ushort(argv[i]))
			return (0 * write(1, "ERROR: invalid argument type\n", 29));
	datas->nb_of_philo = ft_uatoi(argv[1]);
	if (datas->nb_of_philo > 200 || datas->nb_of_philo < 1)
		return (0 * write(1, "ERROR: 1 <= nb_of_philo <= 200\n", 31));
	datas->time_to_die = ft_uatoi(argv[2]);
	datas->time_to_eat = ft_uatoi(argv[3]) * 1000;
	datas->time_to_sleep = ft_uatoi(argv[4]) * 1000;
	datas->finished_eating = 0;
	datas->end_status = 0;
	datas->threads_finished = 0;
	gettimeofday(&datas->start_time, NULL);
	pthread_mutex_init(&datas->global_lock, NULL);
	if (argc == 6)
	{
		datas->meal_limit = ft_uatoi(argv[5]);
		if (datas->meal_limit == 0)
			return (0 * write(1, "ERROR: 1 <= meal_limit\n", 23));
	}
	else
		datas->meal_limit = NO_MEAL_LIMIT;
	return (1);
}

char	init_philosophers(t_datas *datas, t_philo **philos)
{
	unsigned int	i;

	*philos == (t_philo *)malloc(datas->nb_of_philo * sizeof(t_philo));
	if (!*philos)
		return (0 * write(1, "ERROR: malloc\n", 24));
	i = 0;
	while (i < datas->nb_of_philo)
	{
		(*philos)[i].id = i + 1;
		(*philos)[i].meal_counter = 0;
		(*philos)[i].last_meal = 0;
		(*philos)[i].datas = datas;
		pthread_mutex_init(&(*philos)[i].eating_start, NULL); //rajouter les handle des errors
		pthread_mutex_init(&(*philos)[i].eating_end, NULL);
		pthread_mutex_lock(&(*philos)[i].eating_start);
		pthread_mutex_lock(&(*philos)[i].eating_end);
		pthread_create(&(*philos)[i].thread, NULL, &philosopher_thread, &(*philos)[i]);
		i++;
	}
}
