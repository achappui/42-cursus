/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: achappui <achappui@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/29 11:04:34 by achappui          #+#    #+#             */
/*   Updated: 2024/02/10 18:24:55 by achappui         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H

# include <stdio.h>
# include <pthread.h>
# include <unistd.h>
# include <stdlib.h>
# include <stdint.h>
# include <sys/time.h>

# define NO_MEAL_LIMIT	65536

typedef char	t_bool;

typedef struct s_datas
{
	unsigned int		nb_of_philo;
	unsigned int		time_to_die;
	unsigned int		time_to_eat;
	unsigned int		time_to_sleep;
	unsigned int		meal_limit;
	unsigned int		finished_eating;
	unsigned int		threads_finished;
	t_bool				end_status;
	pthread_mutex_t		global_lock;
	struct timeval		start_time;
}	t_datas;

typedef struct s_philo
{
	pthread_t			thread;
	unsigned int		id;
	unsigned int		meal_counter;
	unsigned int		last_meal;
	pthread_mutex_t		eating_start;
	pthread_mutex_t		eating_end;
	t_datas				*datas;
}	t_philo;

void			*counter_thread(void *args);
void			*philosopher_thread(void *args);
char			init_datas(t_datas *datas, int argc, char *argv[]);
char			init_philosophers(t_datas *datas, t_philo **philos);
void			simulation_monitor(t_datas *datas, t_philo *philos);

unsigned int	get_time(struct timeval *start_time);
char			valid_ushort(const char *str);
int				ft_uatoi(const char *str);
int				ft_strlen(const char *s);

#endif