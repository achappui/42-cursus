/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: achappui <achappui@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/29 11:06:41 by achappui          #+#    #+#             */
/*   Updated: 2024/02/10 18:25:01 by achappui         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

/*
	Je suis parti du principe que aucune fonction n'echoue.
*/

void	free_philosophers(t_datas *datas, t_philo *philos)
{
	unsigned int	i;

	i = 0;
	while (i < datas->nb_of_philo)
	{
		pthread_join(philos[i].thread, NULL);
		pthread_mutex_destroy(&philos[i].eating_start);
		pthread_mutex_destroy(&philos[i].eating_end);
	}
	free(philos);
}

int	main(int argc, char *argv[])
{
	t_datas		datas;
	t_philo		*philos;

	if (!init_datas(&datas, argc, argv))
		return (1);
	if (!init_philosophers(&datas, &philos))
		return (1);
	simulation_monitor(&datas, philos);
	free_philosophers(&datas, philos);
	return (0);
}
